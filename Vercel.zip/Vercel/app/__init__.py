import os
from flask import Flask

def create_app():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    app = Flask(
        __name__,
        static_folder=os.path.join(base_dir, 'static'),
        template_folder=os.path.join(base_dir, 'templates')
    )

    app.config['SECRET_KEY'] = 'super-secret-key'  # required for sessions

    from app.routes.login import login_bp

    app.register_blueprint(login_bp, url_prefix='/login')

    return app
